import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";

import Product from "../product";
import StyleProduct from "../../styles/Product.module.css";
import Style from "../../styles/Product.module.css";
function ListProduct({ data }) {
  return (
    <div className={Style.list}>
      {data.map((product) => {
        return (
          <div className={StyleProduct.item}>
            <Image src={product.image} width={120} height={100} />
            <div className={StyleProduct.detail}>
              <h1 className={StyleProduct.title}>{product.title}</h1>
              <p>{product.price} $</p>
              <Link href={"/product/" + product.id} key={product.id}>
                <button className={StyleProduct.btn}>Buy Now</button>
              </Link>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export async function getStaticProps() {
  let products = await fetch("https://fakestoreapi.com/products");

  let data = await products.json();
  console.log(data);
  return { props: { data } };
}

export default ListProduct;
