import Product from "../product";
import Style from '../../styles/Detail.module.css';
export const getStaticPaths = async () =>{
    let products  = await fetch('https://fakestoreapi.com/products');
        
        let data = await products.json();
        let paths = data.map(product =>{
            return {params:{id:product.id.toString()}}
        }  );

    return {
        paths,
    fallback:false}
}


export const getStaticProps = async (context) =>{
    let id = context.params.id;
    let product = await fetch('https://fakestoreapi.com/products/' + id);
        
    let data = await product.json();

    return {props:{product:data}}
}
const Detail = ({product}) => {
    return ( 
        <div className={Style.detail}>
            <Product key={product.id} product={product}></Product>
        </div>
    
     );
}
 
export default Detail;